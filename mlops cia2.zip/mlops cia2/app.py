from flask import Flask, request, render_template
import pickle
import mysql.connector as sql

app = Flask(__name__)

with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

mydb = sql.connect(
    host="localhost",
    user="root",
    password="hussain2004m"
    , database="mlopscia2"
)
@app.route('/')
def main():
    print("------abc-----")
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login_check():
    username = request.form['username']
    password = request.form['password']
    mydb = sql.connect(host="localhost",
    user="root",
    password="hussain2004m"
    , database="mlopscia2"
    )
    mycursor = mydb.cursor()
    mycursor.execute("select * from login")
    data = mycursor.fetchall()
    username_list=[]
    password_list=[]

    for i in data:
        username_list.append(i[0])
        password_list.append(i[-1])

    if username not in username_list:
        return render_template('login.html',msg="Invalid username or password")
    else:
        if password not in password_list:
            return render_template('login.html',msg="Invalid username or password")
        else:
            return render_template("predict.html")
        
@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        Height = (request.form.get('Height'))
        Weight = (request.form.get('Weight'))
        prediction = model.predict([[Height, Weight]])[0]
        if prediction == 1:
            return render_template("result.html", value = 1)
        else:
            return render_template("result.html", value = 0)
    else:
        return render_template('predict.html')

if __name__ == '__main__':
    print("----start-----")
    app.run(host = 'localhost' , port=5000)
